import { Component} from '@angular/core';
import { MDBModalRef, MDBModalService } from 'angular-bootstrap-md';




@Component({
  selector: 'app-publicaciones',
  templateUrl: './publicaciones.component.html',
  styleUrls: ['./publicaciones.component.css']
})
export class PublicacionesComponent {

  constructor() { }
}

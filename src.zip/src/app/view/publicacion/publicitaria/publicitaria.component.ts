import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publicitaria',
  templateUrl: './publicitaria.component.html',
  styleUrls: ['../publicacion.component.css']
})
export class PublicitariaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

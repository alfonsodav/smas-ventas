import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cambiar-atributos',
  templateUrl: './cambiar-atributos.component.html',
  styleUrls: ['../publicacion.component.css']
})
export class CambiarAtributosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
